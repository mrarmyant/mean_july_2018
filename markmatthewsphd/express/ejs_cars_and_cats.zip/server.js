var express = require("express");
// var http = require('http');
var app = express();
// var server = http.createServer(function (request, response){
 app.set('views', __dirname + "/views");
 console.log(__dirname)
 app.set('view engine', 'ejs');


app.get("/", function (request, response){
  response.send("Cars and cats");
})

app.get("/cars", function (request, response){
  response.render("cars");
})
// app.get("/cats", function (request, response){
//   response.render("cats")
// })
//
// app.get("/new", function (request, response){
//   response.render("new")
// })
//
app.use(express.static(__dirname +"/static"));
//

app.listen(8000, function(){
  console.log("listening on 8000");
})
